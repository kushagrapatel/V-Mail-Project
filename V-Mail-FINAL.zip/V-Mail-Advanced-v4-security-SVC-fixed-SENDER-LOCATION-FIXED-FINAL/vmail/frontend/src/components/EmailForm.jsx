import React, { useState } from 'react';
import {
  Alert, AlertIcon, Badge, Box, Button, Divider, Grid, Heading, HStack,
  Icon, Progress, ScaleFade, Spinner, Stat, StatHelpText, StatLabel,
  StatNumber, Text, Textarea, VStack, useColorModeValue
} from '@chakra-ui/react';
import { FiAlertTriangle, FiCheckCircle, FiClock, FiEye, FiShield, FiTrendingUp, FiMapPin, FiRefreshCw } from 'react-icons/fi';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_BASE_URL || 'http://127.0.0.1:5000';

function EmailForm({ onPrediction }) {
  const [emailText, setEmailText] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [analysisTime, setAnalysisTime] = useState(null);
  const borderColor = useColorModeValue('gray.200', 'gray.600');
  const muted = useColorModeValue('gray.600', 'gray.300');

  const handleSubmit = async () => {
    if (!emailText.trim()) return;
    setLoading(true); setResult(null);
    const start = performance.now();
    try {
      const response = await axios.post(`${API_URL}/predict`, { email: emailText });
      setAnalysisTime(((performance.now() - start) / 1000).toFixed(2));
      setResult(response.data); onPrediction?.(response.data);
    } catch (error) {
      setResult({ error: true, message: error.response?.data?.error || 'Unable to connect to the detection API.' });
    } finally { setLoading(false); }
  };

  const clearForm = () => { setEmailText(''); setResult(null); setAnalysisTime(null); };
  const color = result?.is_phishing ? 'red' : 'green';

  return (
    <VStack spacing={6} w="100%" align="stretch">
      <Box>
        <HStack justify="space-between" mb={3}>
          <Text fontSize="sm" fontWeight="700">Email Content</Text>
          <Badge colorScheme={emailText.length > 80000 ? 'red' : 'purple'}>{emailText.length.toLocaleString()} chars</Badge>
        </HStack>
        <Textarea value={emailText} onChange={e => setEmailText(e.target.value)}
          placeholder="Paste the complete email, including subject, sender details and body..."
          minH="230px" resize="vertical" bg="white" color="gray.800"
          border="2px solid" borderColor={borderColor} borderRadius="xl"
          _placeholder={{color:'gray.400'}} _focus={{borderColor:'purple.400', boxShadow:'0 0 0 1px var(--chakra-colors-purple-400)'}} />
        <Text fontSize="xs" color={muted} mt={2}>Email text is processed in memory; analytics store metadata only.</Text>
      </Box>

      <HStack justify={{base:'stretch',md:'center'}} spacing={3}>
        <Button colorScheme="purple" size="lg" onClick={handleSubmit} isDisabled={loading || !emailText.trim()}
          leftIcon={loading ? <Spinner size="sm"/> : <Icon as={FiShield}/>} flex={{base:1,md:'initial'}}>
          {loading ? 'Analyzing...' : 'Run Security Analysis'}
        </Button>
        <Button size="lg" variant="outline" onClick={clearForm} isDisabled={loading || !emailText}>Clear</Button>
      </HStack>

      {loading && <ScaleFade initialScale={.96} in><Box p={5} rounded="xl" bg="gray.50">
        <VStack spacing={3}><HStack><Icon as={FiClock} color="purple.400"/><Text fontSize="sm">Running ML classification and explainable signal analysis...</Text></HStack>
        <Progress isIndeterminate w="100%" colorScheme="purple" rounded="full"/></VStack>
      </Box></ScaleFade>}

      {result?.error && <Alert status="error" rounded="xl"><AlertIcon/>{result.message}</Alert>}

      {result && !result.error && !loading && <ScaleFade initialScale={.96} in>
        <Box bg="white" rounded="2xl" shadow="xl" border="1px solid" borderColor={`${color}.200`} overflow="hidden">
          <Box px={6} py={5} bg={result.is_phishing ? 'red.50' : 'green.50'}>
            <HStack spacing={4} align="start">
              <Icon as={result.is_phishing ? FiAlertTriangle : FiCheckCircle} boxSize={9} color={`${color}.500`} mt={1}/>
              <Box flex="1">
                <Heading size="md" color={`${color}.700`}>{result.is_phishing ? 'Potential Phishing Email' : 'Email Classified as Safe'}</Heading>
                <Text fontSize="sm" color={`${color}.700`} mt={1}>{result.threat_type}</Text>
              </Box>
              <Badge colorScheme={result.risk_level==='CRITICAL'||result.risk_level==='HIGH'?'red':result.risk_level==='MEDIUM'?'orange':'green'} fontSize="sm" px={3} py={1} rounded="full">{result.risk_level} RISK</Badge>
            </HStack>
          </Box>
          <Box p={6}>
            <Grid templateColumns={{base:'1fr',md:'repeat(5,1fr)'}} gap={5}>
              <Stat><StatLabel><HStack><Icon as={FiTrendingUp}/><Text>Confidence</Text></HStack></StatLabel><StatNumber color={`${color}.500`}>{Math.round(result.confidence*100)}%</StatNumber><StatHelpText>Model output</StatHelpText></Stat>
              <Stat><StatLabel>Risk Score</StatLabel><StatNumber color={result.risk_score>=75?'red.500':result.risk_score>=45?'orange.500':'green.500'}>{result.risk_score}/100</StatNumber><StatHelpText>Triage score</StatHelpText></Stat><Stat><StatLabel>Trust Score</StatLabel><StatNumber color={result.trust_score>=70?'green.500':result.trust_score>=40?'orange.500':'red.500'}>{result.trust_score}/100</StatNumber><StatHelpText>Higher = safer</StatHelpText></Stat>
              <Stat><StatLabel><HStack><Icon as={FiEye}/><Text>Indicators</Text></HStack></StatLabel><StatNumber>{result.indicators?.signal_count ?? 0}</StatNumber><StatHelpText>{result.indicators?.url_count ?? 0} URLs · {result.indicators?.domain_count ?? 0} domains</StatHelpText></Stat>
              <Stat><StatLabel><HStack><Icon as={FiClock}/><Text>Response</Text></HStack></StatLabel><StatNumber fontSize="xl">{analysisTime}s</StatNumber><StatHelpText>API round trip</StatHelpText></Stat>
            </Grid>

            <Divider my={6}/>
            <Box p={4} rounded="xl" bg="gray.50" border="1px solid" borderColor="gray.200">
              <HStack mb={2}><Icon as={FiMapPin} color="purple.500"/><Heading size="sm">Sender Location</Heading></HStack>
              {result.sender_location?.available ? <Grid templateColumns={{base:'1fr',md:'repeat(4,1fr)'}} gap={3} fontSize="sm">
                <Box><Text color="gray.500">Location</Text><Text fontWeight="700">{[result.sender_location.city,result.sender_location.region,result.sender_location.country].filter(Boolean).join(', ') || 'Unknown'}</Text></Box>
                <Box><Text color="gray.500">IP</Text><Text fontWeight="700">{result.sender_location.ip || 'Unknown'}</Text></Box>
                <Box><Text color="gray.500">Network</Text><Text fontWeight="700">{result.sender_location.isp || result.sender_location.organization || 'Unknown'}</Text></Box>
                <Box><Text color="gray.500">ASN</Text><Text fontWeight="700">{result.sender_location.asn || 'Unknown'}</Text></Box>
              </Grid> : <VStack align="stretch" spacing={2}>
                {result.sender_location?.ip && <Box><Text fontSize="xs" color="gray.500">Detected public sender IP</Text><Text fontWeight="700" fontSize="sm">{result.sender_location.ip}</Text></Box>}
                <HStack justify="space-between" align="start">
                  <Text fontSize="sm" color="gray.600">{result.sender_location?.reason || 'No public sender IP found. Include the complete email headers (especially Received/X-Originating-IP) for an approximate location.'}</Text>
                  {result.sender_location?.ip && <Button size="xs" variant="outline" leftIcon={<Icon as={FiRefreshCw}/>} onClick={async () => {
                    try {
                      const r = await axios.get(`${API_URL}/geoip/${encodeURIComponent(result.sender_location.ip)}`);
                      setResult(prev => ({...prev, sender_location: r.data}));
                    } catch (e) {
                      setResult(prev => ({...prev, sender_location: {...prev.sender_location, reason: e.response?.data?.error || 'Retry failed. Check backend Internet/DNS access.'}}));
                    }
                  }}>Retry Location</Button>}
                </HStack>
                {result.sender_location?.hint && <Text fontSize="xs" color="gray.500">{result.sender_location.hint}</Text>}
              </VStack>}
              <Text fontSize="xs" color="gray.500" mt={2}>Location is an approximate public IP/mail-server location, not the sender's exact physical location.</Text>
            </Box>

            <Divider my={6}/>
            <HStack justify="space-between" mb={3}><Heading size="sm">Explainable Security Signals</Heading><Button size="sm" leftIcon={<Icon as={FiTrendingUp}/>} as="a" href={`${API_URL}/analysis/${result.id}/report.pdf`}>Download PDF Report</Button></HStack>
            <VStack align="stretch" spacing={2}>
              {(result.signals || []).map((s, i) => (
                <HStack key={`${s.code}-${i}`} p={3} rounded="lg" bg="gray.50" justify="space-between" align="start">
                  <Box><Text fontWeight="700" fontSize="sm">{s.title}</Text><Text fontSize="xs" color="gray.600">{s.detail}</Text></Box>
                  <Badge colorScheme={s.severity==='high'?'red':s.severity==='medium'?'orange':'gray'}>{s.severity}</Badge>
                </HStack>
              ))}
            </VStack>

            {result.indicators?.domains?.length > 0 && <Box mt={5}><Text fontWeight="700" fontSize="sm" mb={2}>Observed Domains</Text>
              <HStack flexWrap="wrap">{result.indicators.domains.map(d=><Badge key={d} variant="outline">{d}</Badge>)}</HStack></Box>}

            <Divider my={6}/>
            <Heading size="sm" mb={3}>Recommended Response</Heading>
            <VStack align="start" spacing={2} color={muted} fontSize="sm">
              {(result.recommendations || []).map((r,i)=><Text key={i}>• {r}</Text>)}
            </VStack>
          </Box>
        </Box>
      </ScaleFade>}
    </VStack>
  );
}
export default EmailForm;
