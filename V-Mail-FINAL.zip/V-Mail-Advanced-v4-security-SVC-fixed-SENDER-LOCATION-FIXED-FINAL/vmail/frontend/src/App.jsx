import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Badge, Box, Button, Container, Divider, Flex, Grid, Heading, HStack, Icon,
  Input, Spinner, Stat, StatHelpText, StatLabel, StatNumber, Table, Tbody,
  Td, Text, Th, Thead, Tr, VStack, useColorModeValue, useToast
} from '@chakra-ui/react';
import { FiActivity, FiAlertTriangle, FiCheckCircle, FiDownload, FiMail, FiRefreshCw, FiShield, FiTrash2, FiTrendingUp, FiFileText, FiLink, FiPaperclip, FiLock, FiSearch, FiGlobe, FiUserCheck, FiDatabase, FiCpu, FiRepeat } from 'react-icons/fi';
import axios from 'axios';
import EmailForm from './components/EmailForm';

const API_URL = process.env.REACT_APP_API_BASE_URL || 'http://127.0.0.1:5000';

function Metric({icon,label,value,help,color}) {
  const bg=useColorModeValue('white','gray.800');
  return <Box bg={bg} border="1px solid" borderColor={useColorModeValue('gray.200','gray.700')} rounded="2xl" p={5} shadow="md">
    <HStack spacing={4}><Flex w="46px" h="46px" align="center" justify="center" rounded="xl" bg={`${color}.50`} color={`${color}.500`}><Icon as={icon} boxSize={6}/></Flex>
    <Stat><StatLabel fontSize="xs" textTransform="uppercase" letterSpacing="wide">{label}</StatLabel><StatNumber fontSize="2xl">{value}</StatNumber><StatHelpText mb={0}>{help}</StatHelpText></Stat></HStack>
  </Box>
}
function Card({title,children,action}) {
 const bg=useColorModeValue('white','gray.800');
 return <Box bg={bg} border="1px solid" borderColor={useColorModeValue('gray.200','gray.700')} rounded="2xl" p={{base:4,md:6}} shadow="md"><Flex justify="space-between" align="center" mb={4}><Heading size="sm">{title}</Heading>{action}</Flex>{children}</Box>
}
function Donut({p,s}) {
 const total=p+s, pp=total?p/total*100:0;
 return <Flex direction="column" align="center" justify="center" minH="250px"><Box w="175px" h="175px" rounded="full" display="flex" alignItems="center" justifyContent="center" background={total?`conic-gradient(#E53E3E 0 ${pp}%, #38A169 ${pp}% 100%)`:'conic-gradient(#CBD5E0 0 100%)'}><Box w="105px" h="105px" rounded="full" bg={useColorModeValue('white','gray.800')} display="flex" alignItems="center" justifyContent="center" flexDirection="column"><Text fontSize="2xl" fontWeight="800">{total}</Text><Text fontSize="xs" color="gray.500">analyses</Text></Box></Box><HStack mt={5} spacing={5} fontSize="sm"><Text>🔴 Phishing {pp.toFixed(1)}%</Text><Text>🟢 Safe {(100-pp).toFixed(1)}%</Text></HStack></Flex>
}
function BarChart({data=[]}) {
 const max=Math.max(1,...data.map(d=>d.count));
 return <VStack align="stretch" spacing={3} minH="250px" justify="center">{data.length ? data.map((d,i)=><Box key={d.label}><Flex justify="space-between" fontSize="xs" mb={1}><Text noOfLines={1} maxW="75%">{d.label}</Text><Text fontWeight="700">{d.count}</Text></Flex><Box h="12px" bg="gray.100" rounded="full" overflow="hidden"><Box h="100%" bg="purple.500" rounded="full" w={`${d.count/max*100}%`} /></Box></Box>) : <Flex minH="250px" align="center" justify="center" color="gray.500">Run analyses to populate frequency data.</Flex>}</VStack>
}
function SecurityArchitecture(){
 const modules=[
  ['Multi-Model Behavioral AI Detection','ML + behavioral heuristics + risk fusion','active',FiCpu],
  ['Advanced BEC & Impersonation Protection','Reply-To mismatch, executive/payment language','active',FiUserCheck],
  ['URL Defense','Click-time local policy check before opening','active',FiLink],
  ['Attachment Sandboxing','Static metadata/extension inspection; no execution','active',FiPaperclip],
  ['Email Authentication','SPF / DKIM / DMARC header result analysis','active',FiCheckCircle],
  ['Data Loss Prevention (DLP)','Sensitive-data pattern detection','active',FiDatabase],
  ['Policy-Based Encryption','Triggers when DLP or high-risk policy matches','policy',FiLock],
  ['Smart Search & Message Tracking','Tracking ID + searchable analytics history','active',FiSearch],
  ['Continuous Protection Architecture','Pre-delivery, click-time and post-delivery stages','active',FiRepeat],
  ['Post-Delivery Remediation','Quarantine/block/review actions for elevated risk','ready',FiShield],
  ['Browser Isolation Integration','Integration-ready recommendation for high-risk links','ready',FiGlobe],
 ];
 return <Card title="Advanced Security Architecture"><Grid templateColumns={{base:'1fr',md:'repeat(2,1fr)',xl:'repeat(3,1fr)'}} gap={4}>{modules.map(([name,desc,status,icon])=><Box key={name} border="1px solid" borderColor="gray.200" rounded="xl" p={4}><HStack align="start"><Flex w="40px" h="40px" rounded="lg" align="center" justify="center" bg="purple.50" color="purple.500"><Icon as={icon}/></Flex><Box flex="1"><Flex justify="space-between" gap={2}><Text fontWeight="700" fontSize="sm">{name}</Text><Badge colorScheme={status==='active'?'green':status==='policy'?'blue':'orange'}>{status}</Badge></Flex><Text fontSize="xs" color="gray.500" mt={1}>{desc}</Text></Box></HStack></Box>)}</Grid><Text fontSize="xs" color="gray.500" mt={4}>Enterprise controls such as real attachment detonation, browser-isolation gateways and enforced encryption require external security infrastructure. V-Mail provides the analysis layer and integration points without executing untrusted content.</Text></Card>
}

function App() {
 const [stats,setStats]=useState(null), [history,setHistory]=useState([]), [online,setOnline]=useState(false), [loading,setLoading]=useState(true), [search,setSearch]=useState('');
 const toast=useToast(), muted=useColorModeValue('gray.600','gray.300');
 const fetchData=useCallback(async()=>{try{const [s,h]=await Promise.all([axios.get(`${API_URL}/stats`),axios.get(`${API_URL}/history?limit=50`)]);setStats(s.data);setHistory(h.data.items||[]);setOnline(true)}catch(e){setOnline(false)}finally{setLoading(false)}},[]);
 useEffect(()=>{fetchData();const t=setInterval(fetchData,15000);return()=>clearInterval(t)},[fetchData]);
 const filtered=useMemo(()=>history.filter(x=>`${x.category} ${x.risk_level} ${x.id}`.toLowerCase().includes(search.toLowerCase())),[history,search]);
 const clear=async()=>{if(!window.confirm('Clear all analytics history?'))return;try{await axios.delete(`${API_URL}/history`);await fetchData();toast({title:'History cleared',status:'success',duration:2500,isClosable:true})}catch(e){toast({title:'Unable to clear history',status:'error'})}};
 return <Box minH="100vh" bg={useColorModeValue('gray.50','gray.900')}>
  <Box as="header" borderBottom="1px solid" borderColor={useColorModeValue('gray.200','gray.700')} bg={useColorModeValue('white','gray.900')} position="sticky" top="0" zIndex="20">
   <Container maxW="1450px" py={4}><Flex justify="space-between" align="center"><HStack><Flex w="44px" h="44px" rounded="xl" align="center" justify="center" bg="purple.500" color="white"><Icon as={FiShield} boxSize={6}/></Flex><Box><Heading size="md">V-Mail</Heading><Text fontSize="xs" color={muted}>Advanced Phishing Detection & Response Center</Text></Box></HStack><HStack><Badge colorScheme={online?'green':'red'} px={3} py={1} rounded="full">{online?'● API Online':'● API Offline'}</Badge><Button size="sm" variant="ghost" onClick={fetchData} leftIcon={<Icon as={FiRefreshCw}/>}>Refresh</Button></HStack></Flex></Container>
  </Box>
  <Container maxW="1450px" py={{base:6,md:10}}><VStack align="stretch" spacing={7}>
   <Flex direction={{base:'column',lg:'row'}} justify="space-between" align={{base:'start',lg:'end'}} gap={4}><Box><Badge colorScheme="purple" mb={3}>SECURITY OPERATIONS</Badge><Heading size="xl">Phishing Detection Center</Heading><Text color={muted} mt={2} maxW="780px">ML classification plus explainable indicators, risk scoring, operational history and exportable security analytics.</Text></Box><HStack fontSize="sm" color={muted}><Icon as={FiActivity}/><Text>Auto-refresh: 15 seconds</Text></HStack></Flex>
   <Grid templateColumns={{base:'1fr',md:'repeat(2,1fr)',xl:'repeat(5,1fr)'}} gap={5}>
    <Metric icon={FiMail} label="Total Analyses" value={loading?<Spinner size="sm"/>:stats?.total??0} help="Recorded predictions" color="purple"/>
    <Metric icon={FiAlertTriangle} label="Phishing Detected" value={loading?<Spinner size="sm"/>:stats?.phishing??0} help={`${stats?.phishing_rate??0}% of analyses`} color="red"/>
    <Metric icon={FiCheckCircle} label="Safe Emails" value={loading?<Spinner size="sm"/>:stats?.safe??0} help={`${stats?.safe_rate??0}% of analyses`} color="green"/>
    <Metric icon={FiTrendingUp} label="Average Confidence" value={loading?<Spinner size="sm"/>:`${Math.round((stats?.average_confidence??0)*100)}%`} help={`${stats?.high_risk_rate??0}% high/critical risk`} color="blue"/>
    <Metric icon={FiShield} label="Average Trust Score" value={loading?<Spinner size="sm"/>:`${Math.round(stats?.average_trust_score??0)}/100`} help="Lower risk = higher trust" color="teal"/>
   </Grid>
   <Box bgGradient="linear(to-r,purple.600,blue.500)" color="white" rounded="3xl" p={{base:5,md:8}} shadow="xl"><HStack mb={3}><Icon as={FiShield}/><Heading size="md">Analyze a New Email</Heading></HStack><Text fontSize="sm" opacity={.9} mb={6}>Run the trained classifier and generate a transparent security triage report.</Text><Box bg="white" color="gray.800" rounded="2xl" p={{base:4,md:6}}><EmailForm onPrediction={fetchData}/></Box></Box>
   <Grid templateColumns={{base:'1fr',lg:'1fr 1fr'}} gap={5}><Card title="Detection Distribution"><Donut p={stats?.phishing||0} s={stats?.safe||0}/></Card>
    <Card title="Daily Detection Trend"><Box minH="250px">{(stats?.trend||[]).length?<VStack align="stretch" spacing={3} pt={2}>{stats.trend.map(d=><Box key={d.date}><Flex justify="space-between" fontSize="xs" mb={1}><Text>{d.date}</Text><Text>{d.phishing} phishing · {d.safe} safe</Text></Flex><Flex h="10px" rounded="full" overflow="hidden" bg="green.100"><Box bg="red.500" w={`${d.total?d.phishing/d.total*100:0}%`}/></Flex></Box>)}</VStack>:<Flex minH="250px" align="center" justify="center" color="gray.500">Run analyses to populate trends.</Flex>}</Box></Card></Grid>
   <Grid templateColumns={{base:'1fr',lg:'1fr 1fr'}} gap={5}>
    <Card title="Detection Bar Chart"><Box minH="250px" pt={2}>{stats ? <Flex h="250px" align="end" justify="center" gap={12}><VStack justify="end" h="100%"><Box w="70px" bg="red.400" h={`${Math.max(8, (stats.phishing/Math.max(1,stats.total))*190)}px`} rounded="md"/><Text fontSize="sm">Phishing</Text><Text fontWeight="700">{stats.phishing}</Text></VStack><VStack justify="end" h="100%"><Box w="70px" bg="green.400" h={`${Math.max(8, (stats.safe/Math.max(1,stats.total))*190)}px`} rounded="md"/><Text fontSize="sm">Safe</Text><Text fontWeight="700">{stats.safe}</Text></VStack></Flex> : <Spinner/>}</Box></Card>
    <Card title="Signal Frequency Chart"><BarChart data={stats?.frequency||[]}/></Card>
   </Grid>
   <SecurityArchitecture/>
   <Card title="Analysis History" action={<HStack><Input size="sm" placeholder="Search ID, category, risk..." value={search} onChange={e=>setSearch(e.target.value)} w={{base:'160px',md:'240px'}}/><Button size="sm" leftIcon={<Icon as={FiDownload}/>} as="a" href={`${API_URL}/history/export.csv`}>Export CSV</Button><Button size="sm" leftIcon={<Icon as={FiFileText}/>} as="a" href={history[0]?.id ? `${API_URL}/analysis/${history[0].id}/report.pdf` : undefined} isDisabled={!history[0]?.id}>Latest PDF</Button><Button size="sm" colorScheme="red" variant="ghost" leftIcon={<Icon as={FiTrash2}/>} onClick={clear}>Clear</Button></HStack>}>
    <Box overflowX="auto"><Table size="sm"><Thead><Tr><Th>ID</Th><Th>Time</Th><Th>Classification</Th><Th>Risk</Th><Th>Confidence</Th><Th>Signals</Th><Th>URLs</Th></Tr></Thead><Tbody>{filtered.length?filtered.map(x=><Tr key={x.id}><Td fontWeight="700">#{x.id}</Td><Td>{new Date(x.timestamp).toLocaleString()}</Td><Td><Badge colorScheme={x.is_phishing?'red':'green'}>{x.category}</Badge></Td><Td><Badge colorScheme={x.risk_level==='CRITICAL'||x.risk_level==='HIGH'?'red':x.risk_level==='MEDIUM'?'orange':'green'}>{x.risk_level}</Badge></Td><Td>{Math.round(x.confidence*100)}%</Td><Td>{x.signal_count}</Td><Td>{x.url_count}</Td></Tr>):<Tr><Td colSpan="7" textAlign="center" py={8} color="gray.500">No matching analyses.</Td></Tr>}</Tbody></Table></Box>
   </Card>
   <Divider/><Text textAlign="center" fontSize="xs" color={muted}> @2026-27 ALL COPYRIGHT FROM V-Mail v2.0 · DEVELOPMENT BY V-MAIL TEAM  </Text>
  </VStack></Container>
 </Box>
}
export default App;
