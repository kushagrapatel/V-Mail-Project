from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from utils import (
    predict_email, get_history, get_stats, get_health,
    get_analysis_detail, clear_history, get_model_info, _url_defense, _attachment_analysis, _lookup_sender_location
)
import csv
import io
import os
import time
import ipaddress
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024  # 100 KB request limit

# In production, set FRONTEND_ORIGIN to the deployed frontend URL.
allowed_origin = os.getenv("FRONTEND_ORIGIN", "*")
CORS(app, resources={r"/*": {"origins": allowed_origin}})

_request_times = {}
RATE_LIMIT = int(os.getenv("RATE_LIMIT_PER_MINUTE", "60"))

def _rate_limited(ip):
    now = time.time()
    window = [t for t in _request_times.get(ip, []) if now - t < 60]
    if len(window) >= RATE_LIMIT:
        _request_times[ip] = window
        return True
    window.append(now)
    _request_times[ip] = window
    return False

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    return response

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "Email payload is too large. Maximum size is 100 KB."}), 413

@app.get("/")
def home():
    return jsonify({
        "status": "ok",
        "service": "V-Mail Advanced Phishing Detection API",
        "version": "2.0.0",
        "endpoints": {
            "health": "/health",
            "model": "/model",
            "predict": "/predict (POST)",
            "stats": "/stats",
            "history": "/history",
            "analysis": "/analysis/<id>",
            "export": "/history/export.csv",
            "clear": "/history (DELETE)",
            "report": "/analysis/<id>/report.pdf",
            "url_check": "/security/url-check (POST)",
            "attachment_scan": "/security/attachment-scan (POST)"
        }
    })

@app.get("/health")
def health():
    return jsonify(get_health())

@app.get("/model")
def model():
    return jsonify(get_model_info())

@app.post("/predict")
def predict():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()
    if _rate_limited(ip):
        return jsonify({"error": "Rate limit exceeded. Please try again shortly."}), 429

    data = request.get_json(silent=True) or {}
    email_text = data.get("email", "")

    if not isinstance(email_text, str) or not email_text.strip():
        return jsonify({"error": "No email content provided."}), 400
    if len(email_text) > 90000:
        return jsonify({"error": "Email content exceeds the 90,000 character limit."}), 400

    try:
        return jsonify(predict_email(email_text.strip()))
    except Exception as exc:
        app.logger.exception("Prediction failed")
        return jsonify({"error": f"Prediction failed: {str(exc)}"}), 500


@app.get("/geoip/<path:ip>")
def geoip(ip):
    """Retry public-IP geolocation independently of a full email analysis."""
    try:
        parsed = ipaddress.ip_address(ip.strip(" []()<>"))
    except ValueError:
        return jsonify({"error": "Invalid IP address."}), 400
    if not parsed.is_global:
        return jsonify({"available": False, "ip": str(parsed), "reason": "The supplied IP is private, loopback, reserved, or otherwise not globally routable."}), 400
    return jsonify(_lookup_sender_location(str(parsed)))

@app.post("/security/url-check")
def security_url_check():
    data = request.get_json(silent=True) or {}
    url = data.get("url", "")
    if not isinstance(url, str) or not url.strip():
        return jsonify({"error": "URL is required."}), 400
    if len(url) > 4096:
        return jsonify({"error": "URL is too long."}), 400
    return jsonify({"mode": "click-time local policy check", "result": _url_defense([url.strip()])[0]})

@app.post("/security/attachment-scan")
def security_attachment_scan():
    data = request.get_json(silent=True) or {}
    name = data.get("filename", "")
    if not isinstance(name, str) or not name.strip():
        return jsonify({"error": "Filename is required."}), 400
    return jsonify(_attachment_analysis(name.strip()))

@app.get("/stats")
def stats():
    try:
        return jsonify(get_stats())
    except Exception as exc:
        app.logger.exception("Stats failed")
        return jsonify({"error": str(exc)}), 500

@app.get("/history")
def history():
    try:
        limit = request.args.get("limit", default=100, type=int)
        return jsonify({"items": get_history(limit)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@app.get("/analysis/<int:analysis_id>")
def analysis(analysis_id):
    item = get_analysis_detail(analysis_id)
    if item is None:
        return jsonify({"error": "Analysis not found."}), 404
    return jsonify(item)

def _format_location(location):
    if not isinstance(location, dict) or not location.get("available"):
        return location.get("reason", "Not available") if isinstance(location, dict) else "Not available"
    parts = [location.get("city"), location.get("region"), location.get("country")]
    return ", ".join(str(x) for x in parts if x) or "Available (details not returned)"

@app.get("/analysis/<int:analysis_id>/report.pdf")
def analysis_report(analysis_id):
    item = get_analysis_detail(analysis_id)
    if item is None:
        return jsonify({"error": "Analysis not found."}), 404
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = [Paragraph("V-Mail Security Analysis Report", styles["Title"]), Spacer(1, 12)]
    trust_by_level = {"CRITICAL": 0, "HIGH": 15, "MEDIUM": 45, "LOW": 75}
    rows = [
        ["Analysis ID", str(item.get("id"))], ["Timestamp", str(item.get("timestamp"))],
        ["Classification", item.get("category", "")], ["Risk Level", item.get("risk_level", "")],
        ["Confidence", f"{float(item.get('confidence', 0))*100:.1f}%"],
        ["Trust Score", f"{trust_by_level.get(item.get('risk_level'), 50)}%"],
        ["Sender IP", str(item.get("sender_ip") or "Not found")],
        ["Sender Location", _format_location(item.get("sender_location"))],
        ["URLs", str(item.get("url_count", 0))], ["Signals", str(item.get("signal_count", 0))]
    ]
    table = Table(rows, colWidths=[150, 350])
    table.setStyle(TableStyle([("BACKGROUND", (0,0), (0,-1), colors.HexColor("#F1F5F9")), ("GRID", (0,0), (-1,-1), .5, colors.HexColor("#CBD5E1")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("PADDING", (0,0), (-1,-1), 8)]))
    story += [table, Spacer(1, 18), Paragraph("Security Signals", styles["Heading2"])]
    signals = item.get("signals", []) or []
    signal_rows = [["Signal", "Severity", "Detail"]] + [[s.get("title", ""), s.get("severity", ""), s.get("detail", "")] for s in signals]
    st = Table(signal_rows, colWidths=[150, 70, 280], repeatRows=1)
    st.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDE9FE")), ("GRID", (0,0), (-1,-1), .5, colors.HexColor("#CBD5E1")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("PADDING", (0,0), (-1,-1), 7)]))
    story += [st, Spacer(1, 18), Paragraph("Advanced Security Controls", styles["Heading2"])]
    modules = item.get("security_modules", {})
    module_rows = [["Control", "Status / Result"]]
    for name, data in modules.items():
        if isinstance(data, dict):
            status = data.get("status") or data.get("mode") or ("Triggered" if data.get("required") else "Not triggered")
        else:
            status = str(data)
        module_rows.append([name.replace("_", " ").title(), str(status)])
    mt = Table(module_rows, colWidths=[190, 310], repeatRows=1)
    mt.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#DBEAFE")), ("GRID", (0,0), (-1,-1), .5, colors.HexColor("#CBD5E1")), ("VALIGN", (0,0), (-1,-1), "TOP"), ("PADDING", (0,0), (-1,-1), 7)]))
    story += [mt, Spacer(1, 18), Paragraph("Recommendations", styles["Heading2"])]
    for rec in item.get("recommendations", []):
        story.append(Paragraph("• " + rec, styles["BodyText"]))
        story.append(Spacer(1, 5))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Sender location is an approximate location of the public IP found in the supplied mail headers; it does not identify the sender's exact physical location.", styles["Italic"]))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Note: Trust/risk scores are triage indicators, not calibrated probabilities.", styles["Italic"]))
    doc.build(story)
    buffer.seek(0)
    return Response(buffer.read(), mimetype="application/pdf", headers={"Content-Disposition": f"attachment; filename=vmail-analysis-{analysis_id}.pdf"})

@app.get("/history/export.csv")
def export_csv():
    rows = get_history(5000)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "timestamp", "is_phishing", "confidence", "risk_level", "category", "url_count", "signal_count"])
    for item in rows:
        writer.writerow([
            item.get("id"), item.get("timestamp"), item.get("is_phishing"),
            item.get("confidence"), item.get("risk_level"), item.get("category"),
            item.get("url_count", 0), item.get("signal_count", 0)
        ])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=vmail-analysis-history.csv"}
    )

@app.delete("/history")
def delete_history():
    clear_history()
    return jsonify({"status": "ok", "message": "Prediction history cleared."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
