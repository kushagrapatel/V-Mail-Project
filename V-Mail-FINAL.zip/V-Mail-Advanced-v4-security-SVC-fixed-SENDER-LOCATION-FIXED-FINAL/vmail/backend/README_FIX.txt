V-MAIL ADVANCED - FIXED BACKEND
================================

1. Copy your existing phishing_detector_latest.pkl into this folder.
2. Open CMD in this folder.
3. Install dependencies if needed:

   python -m pip install Flask flask-cors scikit-learn

4. Check your scikit-learn version:

   python -c "import sklearn; print(sklearn.__version__)"

5. Start the backend:

   python app.py

6. Test in the browser:

   http://127.0.0.1:5000/
   http://127.0.0.1:5000/health
   http://127.0.0.1:5000/model

IMPORTANT:
- Do NOT paste Python compatibility code into the Email Content box.
- The compatibility code is already inside utils.py.
- The .pkl model is not included because it was not available as an uploaded file.
- Keep phishing_detector_latest.pkl beside app.py and utils.py.
