import json
import os
import pickle
import re
import sqlite3
import ipaddress
import urllib.request
import hashlib
import base64
from urllib.parse import urlparse
from datetime import datetime, timezone

BASE_DIR = os.path.dirname(__file__)
MODEL_PATH = os.path.join(BASE_DIR, "phishing_detector_latest.pkl")
DB_PATH = os.path.join(BASE_DIR, "vmail_analytics.db")

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

URL_RE = re.compile(r"https?://[^\s<>\"]+|www\.[^\s<>\"]+", re.I)
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
IP_URL_RE = re.compile(r"https?://(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?", re.I)

URGENT_TERMS = [
    "urgent", "immediately", "verify your account", "account suspended",
    "confirm your identity", "action required", "within 24 hours",
    "security alert", "password expires", "click here", "login now"
]
FINANCIAL_TERMS = [
    "bank", "payment", "invoice", "refund", "gift card", "wire transfer",
    "credit card", "crypto", "bitcoin", "payment details"
]
CREDENTIAL_TERMS = ["password", "username", "otp", "one-time password", "verification code", "login"]
ATTACHMENT_TERMS = ["attachment", ".exe", ".zip", ".rar", ".scr", ".js", ".bat", ".docm", ".xlsm"]

# Header patterns deliberately accept brackets, parentheses and whitespace because
# real mail headers are not formatted consistently.
IP_HEADER_RE = re.compile(
    r'(?im)^\s*(?:X-Originating-IP|X-Sender-IP|X-Client-IP|X-Real-IP|X-Remote-IP)\s*:\s*(?:\[|\(|\s)*'
    r'((?:\d{1,3}\.){3}\d{1,3})'
)
IP_ANY_RE = re.compile(r'(?<![\d.])((?:\d{1,3}\.){3}\d{1,3})(?![\d.])')
RECEIVED_LINE_RE = re.compile(r'(?im)^\s*Received\s*:\s*(.*?)(?:\r?\n(?![ \t])|$)')

def _is_public_ip(value):
    try:
        ip = ipaddress.ip_address(value.strip(' []()<>'))
        return ip.is_global
    except ValueError:
        return False

def _extract_sender_ip(text):
    """Return the first useful public IP from explicit IP headers, then
    the oldest public IP in the Received chain.  Private/loopback/reserved
    addresses are intentionally ignored.
    """
    text = text or ''
    for match in IP_HEADER_RE.findall(text):
        if _is_public_ip(match):
            return match

    # Received headers are ordered newest -> oldest. Prefer the last public
    # hop because it is normally closest to the originating mail infrastructure.
    candidates = []
    for line in RECEIVED_LINE_RE.findall(text):
        candidates.extend(IP_ANY_RE.findall(line))
    for match in reversed(candidates):
        if _is_public_ip(match):
            return match

    # Some pasted headers lose the "Received:" prefix. Fall back to scanning
    # the whole header block, but only after the explicit patterns above.
    for match in IP_ANY_RE.findall(text):
        if _is_public_ip(match):
            return match
    return None

def _lookup_sender_location(ip):
    """Best-effort geolocation of a public mail-server/header IP.

    Providers are intentionally tried in sequence because corporate networks,
    DNS filters and ISP firewalls may block one geolocation service.  The
    function always returns the detected public IP even when every provider is
    unavailable, so the UI never loses the useful header evidence.
    """
    if not ip:
        return {
            "available": False,
            "ip": None,
            "reason": "No public sender IP was found in the supplied headers."
        }

    providers = [
        # ip-api has a free HTTP endpoint and is useful on local HTTP installs
        # where HTTPS-only services are blocked by a firewall/DNS filter.
        (
            f"http://ip-api.com/json/{ip}?fields=status,message,country,regionName,city,isp,org,as,lat,lon,query",
            lambda d: d.get("status") == "success",
            lambda d: {
                "country": d.get("country"), "region": d.get("regionName"),
                "city": d.get("city"), "isp": d.get("isp"),
                "organization": d.get("org"), "asn": d.get("as"),
                "latitude": d.get("lat"), "longitude": d.get("lon"),
            },
        ),
        (
            f"https://ipwho.is/{ip}",
            lambda d: d.get("success") is True,
            lambda d: {
                "country": d.get("country"), "region": d.get("region"),
                "city": d.get("city"), "isp": (d.get("connection") or {}).get("isp"),
                "organization": (d.get("connection") or {}).get("org"),
                "asn": (d.get("connection") or {}).get("asn"),
                "latitude": d.get("latitude"), "longitude": d.get("longitude"),
            },
        ),
        (
            f"https://ipwhois.app/json/{ip}",
            lambda d: d.get("success") is True or d.get("success") == "true",
            lambda d: {
                "country": d.get("country"), "region": d.get("region"),
                "city": d.get("city"), "isp": d.get("isp"),
                "organization": d.get("org"), "asn": d.get("asn"),
                "latitude": d.get("latitude"), "longitude": d.get("longitude"),
            },
        ),
        (
            f"https://freeipapi.com/api/json/{ip}",
            lambda d: bool(d.get("ipAddress") or d.get("ipVersion") or d.get("countryName")),
            lambda d: {
                "country": d.get("countryName"), "region": d.get("regionName"),
                "city": d.get("cityName"), "isp": d.get("isp"),
                "organization": d.get("organization"), "asn": d.get("asn"),
                "latitude": d.get("latitude"), "longitude": d.get("longitude"),
            },
        ),
        (
            f"https://ipapi.co/{ip}/json/",
            lambda d: not d.get("error"),
            lambda d: {
                "country": d.get("country_name"), "region": d.get("region"),
                "city": d.get("city"), "isp": d.get("org"),
                "organization": d.get("org"), "asn": d.get("asn"),
                "latitude": d.get("latitude"), "longitude": d.get("longitude"),
            },
        ),
    ]

    last_reason = "All configured geolocation providers were unavailable or blocked."
    for url, ok, mapper in providers:
        try:
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "V-Mail-Advanced/4.0 SenderLocation/2.0",
                    "Accept": "application/json",
                    "Cache-Control": "no-cache",
                },
            )
            with urllib.request.urlopen(req, timeout=7) as response:
                data = json.loads(response.read().decode("utf-8", errors="replace"))
            if ok(data):
                details = mapper(data)
                # A provider can technically return success without a city.
                # Keep the result usable as long as it has at least country,
                # region, city, ISP or coordinates.
                if any(details.get(k) not in (None, "", "Unknown") for k in (
                    "country", "region", "city", "isp", "organization", "latitude", "longitude"
                )):
                    return {
                        "available": True,
                        "ip": ip,
                        **details,
                        "source": "Public IP geolocation provider",
                    }
            last_reason = data.get("message") or data.get("reason") or last_reason
        except Exception as exc:
            last_reason = f"Geolocation providers unavailable: {type(exc).__name__}"
            continue

    # Preserve the evidence instead of returning a blank location card.
    return {
        "available": False,
        "ip": ip,
        "reason": last_reason,
        "detected_ip": ip,
        "hint": "The public sender IP was detected, but the geolocation providers could not be reached from this server. Check Internet/DNS/firewall access and use Retry Location."
    }

def _db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def _init_db():
    with _db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                is_phishing INTEGER NOT NULL,
                confidence REAL NOT NULL,
                category TEXT NOT NULL,
                threat_type TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                email_length INTEGER NOT NULL,
                url_count INTEGER NOT NULL,
                domain_count INTEGER NOT NULL,
                signal_count INTEGER NOT NULL,
                signals_json TEXT NOT NULL,
                sender_ip TEXT,
                sender_location_json TEXT
            )
        """)
        conn.commit()
        for column, definition in (("sender_ip", "TEXT"), ("sender_location_json", "TEXT"), ("security_modules_json", "TEXT")):
            try:
                conn.execute(f"ALTER TABLE analyses ADD COLUMN {column} {definition}")
            except sqlite3.OperationalError:
                pass
        conn.commit()

    # One-time migration from the original JSON analytics file.
    legacy = os.path.join(BASE_DIR, "prediction_history.json")
    marker = os.path.join(BASE_DIR, ".legacy_migrated")
    if os.path.exists(legacy) and not os.path.exists(marker):
        try:
            with open(legacy, "r", encoding="utf-8") as f:
                old_items = json.load(f)
            with _db() as conn:
                for item in old_items if isinstance(old_items, list) else []:
                    conn.execute("""INSERT INTO analyses
                        (timestamp,is_phishing,confidence,category,threat_type,risk_level,
                         email_length,url_count,domain_count,signal_count,signals_json)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                        (item.get("timestamp", datetime.now(timezone.utc).isoformat()),
                         int(bool(item.get("is_phishing"))), float(item.get("confidence", 0.5)),
                         item.get("category", "Phishing Email" if item.get("is_phishing") else "Safe Email"),
                         item.get("threat_type", "Migrated legacy prediction"), item.get("risk_level", "MEDIUM"),
                         0, 0, 0, 0, "[]"))
                conn.commit()
            with open(marker, "w", encoding="utf-8") as f: f.write("migrated")
        except Exception:
            pass

_init_db()

def _patch_sklearn_compatibility(obj):
    """Patch serialized scikit-learn estimators for SVC version compatibility.

    The bundled model is a Pipeline -> VotingClassifier -> SVC. Some
    scikit-learn releases expect SVC._effective_probability to exist when
    predict/predict_proba is called. Pickles created by another release may
    not contain that internal attribute. Walk nested estimators and add it
    only when missing; never replace the trained model or its parameters.
    """
    seen = set()

    def visit(current):
        if current is None or id(current) in seen:
            return
        seen.add(id(current))

        if current.__class__.__name__ == "SVC":
            if not hasattr(current, "_effective_probability"):
                current._effective_probability = bool(
                    getattr(current, "probability", False)
                )

        # sklearn meta-estimators expose fitted estimators here.
        for attr in ("estimators_", "estimators"):
            try:
                children = getattr(current, attr, None)
            except Exception:
                children = None
            if children:
                try:
                    for child in children:
                        if isinstance(child, tuple) and len(child) >= 2:
                            child = child[1]
                        visit(child)
                except TypeError:
                    pass

        # Pipelines / meta-estimators can also expose named_steps.
        try:
            named_steps = getattr(current, "named_steps", None)
            if named_steps:
                for child in named_steps.values():
                    visit(child)
        except Exception:
            pass

    try:
        visit(obj)
    except Exception:
        # Compatibility patch must never prevent the application from starting.
        pass


_patch_sklearn_compatibility(model)

def _normalise_label(value):
    return str(value).strip().lower()

def _confidence_from_decision(decision):
    try:
        if hasattr(decision, "__len__") and not isinstance(decision, (str, bytes)):
            values = [float(x) for x in decision]
            if len(values) == 1:
                margin = abs(values[0])
            elif values:
                top = sorted(values, reverse=True)
                margin = top[0] - top[1] if len(top) > 1 else abs(top[0])
            else:
                return 0.5
        else:
            margin = abs(float(decision))
        # Bounded confidence-like score; it is not a calibrated probability.
        import math
        return max(0.5, min(1.0 / (1.0 + math.exp(-margin)), 0.9999))
    except (TypeError, ValueError, OverflowError):
        return 0.5

def _get_confidence(features, prediction):
    """
    Get a confidence-like score safely.

    For SVC models, predict_proba() can fail when the saved model
    was created with an incompatible scikit-learn version or without
    probability calibration. In that case, use decision_function().
    """

    # Try probability prediction first.
    predict_proba = getattr(model, "predict_proba", None)

    if callable(predict_proba):
        try:
            probabilities = predict_proba(features)[0]
            classes = list(getattr(model, "classes_", []))

            if classes and prediction in classes:
                return float(probabilities[classes.index(prediction)])

        except Exception:
            # Some saved SVC models can expose predict_proba()
            # but fail internally because of version incompatibility.
            pass

    # Fall back to SVC decision_function().
    decision_function = getattr(model, "decision_function", None)

    if callable(decision_function):
        try:
            decision = decision_function(features)
            return _confidence_from_decision(decision)
        except Exception:
            pass

    # Safe fallback if neither method is usable.
    return 0.5


DLP_PATTERNS = {
    "credit_card": re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
    "upi": re.compile(r"\b[a-z0-9._-]{2,}@[a-z]{2,}\b", re.I),
    "phone": re.compile(r"\b(?:\+91[- ]?)?[6-9]\d{9}\b"),
    "secret_key": re.compile(r"\b(?:api[_-]?key|secret|access[_-]?token)\s*[:=]\s*[A-Za-z0-9_\-]{12,}\b", re.I),
}
DANGEROUS_EXTENSIONS = {".exe", ".dll", ".scr", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar", ".msi", ".iso"}
MACRO_EXTENSIONS = {".docm", ".xlsm", ".pptm"}

def _domain_from_email_header(text):
    m = re.search(r'(?im)^\s*from:\s*(?:.*?<)?([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})', text)
    return m.group(1).split('@',1)[1].lower() if m else None

def _authentication_checks(text):
    lower = text.lower()
    result = {}
    for key in ("spf", "dkim", "dmarc"):
        m = re.search(rf'(?im)^\s*{key}\s*[:=]\s*(pass|fail|softfail|neutral|none|temperror|permerror)', text)
        result[key] = m.group(1).lower() if m else "not_found"
    # Also understand common Authentication-Results syntax.
    if "dmarc=pass" in lower: result["dmarc"] = "pass"
    elif "dmarc=fail" in lower: result["dmarc"] = "fail"
    if "dkim=pass" in lower: result["dkim"] = "pass"
    elif "dkim=fail" in lower: result["dkim"] = "fail"
    if "spf=pass" in lower: result["spf"] = "pass"
    elif "spf=fail" in lower: result["spf"] = "fail"
    return result

def _bec_impersonation(text):
    lower = text.lower()
    signals=[]
    from_domain = _domain_from_email_header(text)
    reply = re.search(r'(?im)^\s*reply-to:\s*.*?@([A-Z0-9.-]+)', text)
    reply_domain = reply.group(1).lower() if reply else None
    lookalike_terms = ["ceo", "director", "manager", "finance", "payroll", "wire transfer", "gift card", "confidential", "urgent payment"]
    hits=[x for x in lookalike_terms if x in lower]
    if from_domain and reply_domain and from_domain != reply_domain:
        signals.append({"code":"BEC_REPLY_DOMAIN","title":"Reply-To domain mismatch","detail":f"From domain {from_domain} differs from Reply-To domain {reply_domain}.","severity":"high"})
    if hits:
        signals.append({"code":"BEC_LANGUAGE","title":"BEC / impersonation language","detail":f"Business-impersonation indicators detected: {', '.join(hits[:5])}.","severity":"medium"})
    return signals

def _url_defense(urls):
    results=[]
    for raw in urls:
        u=raw if raw.lower().startswith(('http://','https://')) else 'http://'+raw
        try:
            parsed=urlparse(u)
            host=(parsed.hostname or '').lower()
            reasons=[]
            if parsed.scheme not in ('http','https'): reasons.append('unsupported scheme')
            if '@' in parsed.netloc: reasons.append('userinfo in URL')
            if host.startswith('xn--') or '.xn--' in host: reasons.append('internationalized/punycode hostname')
            if re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}', host): reasons.append('raw IP host')
            if len(u)>200: reasons.append('unusually long URL')
            verdict='review' if reasons else 'allowed_pending_reputation'
            results.append({"url":raw,"verdict":verdict,"reasons":reasons or ['No local URL policy violation detected.']})
        except Exception:
            results.append({"url":raw,"verdict":"blocked","reasons":["Malformed URL"]})
    return results

def _attachment_analysis(text):
    names=re.findall(r'(?i)\b[^\s<>"\']+\.(?:exe|dll|scr|bat|cmd|ps1|vbs|js|jar|msi|iso|zip|rar|7z|docm|xlsm|pptm|pdf|docx|xlsx|pptx)\b', text)
    items=[]
    for name in sorted(set(names)):
        ext='.'+name.rsplit('.',1)[-1].lower()
        if ext in DANGEROUS_EXTENSIONS: risk='high'
        elif ext in MACRO_EXTENSIONS: risk='high'
        elif ext in {'.zip','.rar','.7z'}: risk='medium'
        else: risk='low'
        items.append({"name":name,"extension":ext,"risk":risk,"sandbox_status":"static-analysis-only"})
    return {"attachments":items,"sandbox":"No files are executed. Metadata and extension policy checks only."}

def _dlp_scan(text):
    findings=[]
    for kind,pat in DLP_PATTERNS.items():
        matches=pat.findall(text)
        if matches: findings.append({"type":kind,"count":len(matches),"action":"review_or_block_by_policy"})
    return findings

def _policy_encryption(dlp_findings, risk_level):
    if dlp_findings or risk_level in ('HIGH','CRITICAL'):
        return {"required":True,"mode":"policy_recommended","reason":"Sensitive-data or elevated-risk indicators detected."}
    return {"required":False,"mode":"not_required","reason":"No local encryption policy trigger detected."}

def _smart_tracking(text, sender_location):
    return {"tracking_id": hashlib.sha256(text.encode('utf-8',errors='ignore')).hexdigest()[:16], "sender_ip": _extract_sender_ip(text), "location_available": bool(isinstance(sender_location,dict) and sender_location.get('available'))}

def _continuous_protection(features):
    return {"enabled":True,"stages":["pre-delivery analysis","click-time URL check","post-delivery remediation"],"browser_isolation":"recommended_for_high_risk_links"}

def _extract_signals(text):
    lower = text.lower()
    urls = URL_RE.findall(text)
    emails = EMAIL_RE.findall(text)
    signals = []

    def add(code, title, detail, severity):
        signals.append({"code": code, "title": title, "detail": detail, "severity": severity})

    urgent_hits = [x for x in URGENT_TERMS if x in lower]
    financial_hits = [x for x in FINANCIAL_TERMS if x in lower]
    credential_hits = [x for x in CREDENTIAL_TERMS if x in lower]
    attachment_hits = [x for x in ATTACHMENT_TERMS if x in lower]

    if urgent_hits:
        add("URGENCY", "Urgency / pressure language", f"Detected terms such as: {', '.join(urgent_hits[:3])}.", "medium")
    if financial_hits:
        add("FINANCIAL", "Financial request language", f"Detected {len(financial_hits)} financial-related term(s).", "high")
    if credential_hits:
        add("CREDENTIAL", "Credential / verification request", "The message references passwords, OTPs, login or verification codes.", "high")
    if attachment_hits:
        add("ATTACHMENT", "Potentially risky attachment language", "The message references attachments or executable/macro-enabled file types.", "high")
    if urls:
        add("URLS", "Links detected", f"{len(urls)} URL(s) were found in the message.", "medium")
    if IP_URL_RE.search(text):
        add("IP_URL", "IP-address URL", "A URL uses a raw IP address instead of a normal domain name.", "high")
    if text.count("!") >= 5:
        add("EXCESS_PUNCT", "Excessive punctuation", "The message contains unusually frequent exclamation marks.", "low")
    if len(text) > 0 and sum(c.isupper() for c in text) / max(1, sum(c.isalpha() for c in text)) > 0.45:
        add("CAPS", "Unusual uppercase ratio", "A high proportion of alphabetic characters are uppercase.", "low")
    if len(urls) >= 3:
        add("MANY_URLS", "Multiple links", "Several links increase the need for manual verification.", "medium")

    domains = set()
    for url in urls:
        cleaned = url if url.lower().startswith(("http://", "https://")) else "http://" + url
        try:
            from urllib.parse import urlparse
            host = urlparse(cleaned).hostname
            if host:
                domains.add(host.lower())
        except Exception:
            pass

    if not signals:
        add("NO_OBVIOUS_SIGNAL", "No obvious heuristic signal", "No high-signal pattern was found by the local rules.", "info")

    return signals, urls, domains

def predict_email(email_text):
    features = [email_text]


    prediction = model.predict(features)[0]
    confidence = _get_confidence(features, prediction)
    label = str(prediction)
    normalised = _normalise_label(label)

    phishing_labels = {"phishing email", "phishing", "phishing_email", "1", "true"}
    is_phishing = normalised in phishing_labels

    signals, urls, domains = _extract_signals(email_text)
    sender_ip = _extract_sender_ip(email_text)
    sender_location = _lookup_sender_location(sender_ip)

    category = "Phishing Email" if is_phishing else "Safe Email"
    threat_type = "Suspicious / phishing content" if is_phishing else "No obvious threat detected"

    bec_signals = _bec_impersonation(email_text)
    auth = _authentication_checks(email_text)
    url_defense = _url_defense(urls)
    attachment_scan = _attachment_analysis(email_text)
    dlp_findings = _dlp_scan(email_text)
    signals.extend(bec_signals)
    if any(v == "fail" for v in auth.values()):
        signals.append({"code":"AUTH_FAIL","title":"Email authentication failure","detail":"One or more SPF, DKIM, or DMARC results indicate failure.","severity":"high"})
    elif all(v == "not_found" for v in auth.values()):
        signals.append({"code":"AUTH_NOT_FOUND","title":"Authentication results not found","detail":"SPF/DKIM/DMARC results were not present in the supplied headers.","severity":"low"})
    # Risk score combines the ML decision with all explainable local indicators.
    # It is intentionally presented as a triage score, not a calibrated probability.
    high = sum(1 for s in signals if s["severity"] == "high")
    medium = sum(1 for s in signals if s["severity"] == "medium")
    signal_score = min(100, high * 22 + medium * 10 + sum(s["severity"] == "low" for s in signals) * 4)
    ml_score = confidence * 100 if is_phishing else (1 - confidence) * 100
    risk_score = round(min(100, 0.70 * ml_score + 0.30 * signal_score))
    trust_score = max(0, 100 - risk_score)
    if risk_score >= 75:
        risk_level = "CRITICAL" if high >= 2 else "HIGH"
    elif risk_score >= 45:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"
    encryption = _policy_encryption(dlp_findings, risk_level)
    signal_count = len(signals)
    remediation = {"recommended": bool(is_phishing or risk_level in ('HIGH','CRITICAL')), "actions":["quarantine","revoke active sessions if credentials were exposed","block matching URLs/domains","notify security team"]}
    tracking = _smart_tracking(email_text, sender_location)
    continuous = _continuous_protection({"risk_level": risk_level})

    recommendations = (
        ["Do not click links or open attachments.",
         "Verify the sender through a trusted channel.",
         "Report the message to your security team or mail provider.",
         "If credentials were entered, change the password and review account activity."]
        if is_phishing else
        ["No obvious phishing signal was detected by the model.",
         "Still verify unexpected payment, login, or credential requests.",
         "Treat links and attachments cautiously."]
    )

    timestamp = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO analyses
            (timestamp,is_phishing,confidence,category,threat_type,risk_level,
             email_length,url_count,domain_count,signal_count,signals_json,sender_ip,sender_location_json,security_modules_json)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (timestamp, int(is_phishing), round(confidence, 4), category, threat_type,
              risk_level, len(email_text), len(urls), len(domains), len(signals), json.dumps(signals),
              sender_ip, json.dumps(sender_location), json.dumps({
                  "multi_model_behavioral_ai": {"status":"active","components":["ML classifier","behavioral heuristics","BEC/impersonation analysis","risk fusion"]},
                  "bec_impersonation": {"status":"active","signals": bec_signals},
                  "url_defense": {"status":"active","mode":"click-time local policy check","results": url_defense},
                  "attachment_sandbox": attachment_scan, "email_authentication": auth, "dlp": dlp_findings,
                  "policy_encryption": encryption, "smart_search_tracking": tracking, "continuous_protection": continuous,
                  "post_delivery_remediation": remediation,
                  "browser_isolation": {"status":"integration_ready","action":"Route high-risk links through an enterprise browser-isolation gateway before opening."}
              })))
        analysis_id = cur.lastrowid
        conn.commit()

    return {
        "id": analysis_id,
        "is_phishing": is_phishing,
        "confidence": round(confidence, 4),
        "risk_score": risk_score,
        "trust_score": trust_score,
        "category": category,
        "threat_type": threat_type,
        "risk_level": risk_level,
        "timestamp": timestamp,
        "sender_location": sender_location,
        "indicators": {
            "url_count": len(urls),
            "domain_count": len(domains),
            "email_length": len(email_text),
            "signal_count": len(signals),
            "domains": sorted(domains)[:20]
        },
        "signals": signals,
        "security_modules": {
            "multi_model_behavioral_ai": {"status":"active","components":["ML classifier","behavioral heuristics","BEC/impersonation analysis","risk fusion"]},
            "bec_impersonation": {"status":"active","signals": bec_signals},
            "url_defense": {"status":"active","mode":"click-time local policy check","results": url_defense},
            "attachment_sandbox": attachment_scan,
            "email_authentication": auth,
            "dlp": dlp_findings,
            "policy_encryption": encryption,
            "smart_search_tracking": tracking,
            "continuous_protection": continuous,
            "post_delivery_remediation": remediation,
            "browser_isolation": {"status":"integration_ready","action":"Route high-risk links through an enterprise browser-isolation gateway before opening."}
        },
        "recommendations": recommendations,
        "privacy": "Email content is analyzed in memory and is not stored in analytics."
    }

def get_history(limit=100):
    limit = max(1, min(int(limit), 5000))
    with _db() as conn:
        rows = conn.execute("""
            SELECT id,timestamp,is_phishing,confidence,category,threat_type,risk_level,
                   email_length,url_count,domain_count,signal_count
            FROM analyses ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
    return [dict(r, is_phishing=bool(r["is_phishing"])) for r in rows]

def get_analysis_detail(analysis_id):
    with _db() as conn:
        row = conn.execute("SELECT * FROM analyses WHERE id=?", (analysis_id,)).fetchone()
    if not row:
        return None
    item = dict(row)
    item["is_phishing"] = bool(item["is_phishing"])
    item["signals"] = json.loads(item.pop("signals_json") or "[]")
    item["sender_location"] = json.loads(item.pop("sender_location_json") or "{}")
    return item

def get_stats():
    with _db() as conn:
        row = conn.execute("""
            SELECT COUNT(*) total,
                   COALESCE(SUM(is_phishing),0) phishing,
                   COALESCE(AVG(confidence),0) average_confidence,
                   COALESCE(AVG(CASE WHEN risk_level IN ('HIGH','CRITICAL') THEN 1.0 ELSE 0.0 END),0) high_risk_rate,
                   COALESCE(AVG(100 - CASE
                       WHEN risk_level='CRITICAL' THEN 100
                       WHEN risk_level='HIGH' THEN 85
                       WHEN risk_level='MEDIUM' THEN 55
                       ELSE 25 END),0) average_trust_score
            FROM analyses
        """).fetchone()
        daily_rows = conn.execute("""
            SELECT substr(timestamp,1,10) date, COUNT(*) total, COALESCE(SUM(is_phishing),0) phishing
            FROM analyses GROUP BY substr(timestamp,1,10) ORDER BY date DESC LIMIT 14
        """).fetchall()
        frequency_rows = conn.execute("""
            SELECT category, COUNT(*) count FROM analyses GROUP BY category ORDER BY count DESC
        """).fetchall()
        signal_rows = conn.execute("""
            SELECT signals_json FROM analyses ORDER BY id DESC LIMIT 5000
        """).fetchall()
    total = int(row["total"]); phishing = int(row["phishing"]); safe = total - phishing
    trend = [{"date": r["date"], "total": int(r["total"]), "phishing": int(r["phishing"]), "safe": int(r["total"]) - int(r["phishing"])} for r in reversed(daily_rows)]
    from collections import Counter
    signal_counts = Counter()
    for r in signal_rows:
        try:
            for signal in json.loads(r["signals_json"] or "[]"):
                signal_counts[signal.get("title", "Unknown signal")] += 1
        except Exception:
            pass
    return {
        "total": total, "phishing": phishing, "safe": safe,
        "phishing_rate": round(phishing / total * 100, 2) if total else 0,
        "safe_rate": round(safe / total * 100, 2) if total else 0,
        "average_confidence": round(float(row["average_confidence"]), 4),
        "average_trust_score": round(float(row["average_trust_score"]), 2),
        "high_risk_rate": round(float(row["high_risk_rate"]) * 100, 2),
        "trend": trend,
        "frequency": [{"label": k, "count": v} for k, v in signal_counts.most_common(8)]
    }

def get_health():
    return {"status": "ok", "service": "email-phishing-detection", "version": "2.0.0", "model_loaded": model is not None}

def get_model_info():
    classes = [str(x) for x in getattr(model, "classes_", [])]
    return {
        "model_type": type(model).__name__,
        "classes": classes,
        "supports_probability": hasattr(model, "predict_proba"),
        "supports_decision_function": hasattr(model, "decision_function"),
        "note": "Confidence is model-derived; risk score also uses explainable local indicators."
    }

def clear_history():
    with _db() as conn:
        conn.execute("DELETE FROM analyses")
        conn.execute("DELETE FROM sqlite_sequence WHERE name='analyses'")
        conn.commit()
