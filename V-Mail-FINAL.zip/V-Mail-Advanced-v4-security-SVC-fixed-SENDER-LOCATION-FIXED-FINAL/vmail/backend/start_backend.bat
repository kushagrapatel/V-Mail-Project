@echo off
cd /d "%~dp0"
echo Starting V-Mail Advanced backend...
python app.py
pause
