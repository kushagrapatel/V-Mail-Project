V-Mail Advanced Security Modules

Added:
- Multi-Model Behavioral AI Detection: combines the existing ML classifier with explainable behavioral heuristics and risk fusion.
- Advanced BEC & Impersonation Protection: detects Reply-To/domain mismatch and common BEC/payment/impersonation language.
- URL Defense (Click-Time Protection): POST /security/url-check performs a fresh local policy check immediately before a link is opened. It does not fetch or execute the URL.
- Attachment Sandboxing: POST /security/attachment-scan performs static filename/extension analysis. No attachment is executed.
- Email Authentication: parses supplied headers for SPF, DKIM and DMARC results.
- Data Loss Prevention (DLP): detects common sensitive-data patterns and returns policy findings.
- Policy-Based Encryption: recommends encryption when DLP or elevated-risk conditions trigger a local policy.
- Smart Search & Message Tracking: creates a short deterministic tracking ID and uses existing searchable analytics history.
- Continuous Protection Architecture: models pre-delivery, click-time and post-delivery stages.
- Post-Delivery Remediation: returns recommended quarantine/block/review actions for elevated-risk messages.
- Browser Isolation Integration: integration-ready recommendation for routing high-risk links through an enterprise isolation gateway.

Important:
Real attachment detonation, browser isolation, enforced encryption, enterprise DNS/reputation feeds, and actual message quarantine require external security infrastructure. This version intentionally performs safe static analysis and exposes integration points rather than executing untrusted files or browsing attacker-controlled URLs.


SENDER LOCATION FIX (v4)
------------------------
Sender Location is derived from a public IP found in the supplied mail headers.
The backend now checks X-Originating-IP/X-Sender-IP/X-Client-IP/X-Real-IP and
Received: headers, ignores private/reserved IPs, and uses HTTPS geolocation with
a fallback provider. A public IP is required; Gmail/Outlook may hide the
originating device IP, so exact physical sender location cannot be determined.

For best results paste the COMPLETE raw email headers together with the body.
