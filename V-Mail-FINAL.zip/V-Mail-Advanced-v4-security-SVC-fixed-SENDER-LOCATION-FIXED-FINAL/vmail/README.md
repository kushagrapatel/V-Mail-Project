# V-Mail Advanced Phishing Detection System

## What changed
- SQLite analytics database instead of a JSON file
- Explainable phishing indicators (urgency, credential requests, financial language, risky attachments, URL/IP signals, etc.)
- Risk score and CRITICAL/HIGH/MEDIUM/LOW triage levels
- Analysis IDs and detailed metadata
- Searchable history table and CSV export
- Clear-history control
- API health/model information endpoints
- 100 KB API payload limit and basic rate limiting
- Security response headers
- Automatic migration of the original `prediction_history.json`
- Improved dashboard and analysis result UI

## Run backend
```powershell
cd backend
python -m pip install -r requirements.txt
python app.py
```

## Run frontend
```powershell
cd frontend
npm install
npm start
```

If PowerShell blocks `npm.ps1`, use Command Prompt in VS Code or run `npm.cmd install` and `npm.cmd start`.

## Important
The existing `.pkl` model is retained. The new risk score is a triage layer around that model and explainable local indicators; it is not a newly trained or calibrated ML model.


## Sender Location
The analyzer now extracts a public IP from common email headers (X-Originating-IP/X-Sender-IP/Received) and performs best-effort IP geolocation. It reports approximate mail-server/network location only; it cannot determine a sender's exact physical location. Complete raw headers should be included for the feature to work.
